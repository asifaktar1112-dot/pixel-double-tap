# Pixel Double Tap

A minimal dark Android app prototype for Pixel phones. Intended behaviour: double-tap an empty area of the home screen to lock the display. It does not replace your launcher.

## Important limitation / permission warning

This prototype uses an Android AccessibilityService and the API 34 `setMotionEventSources(SOURCE_TOUCHSCREEN)` interface. Android's official API documentation says motion events requested this way are not delivered to the rest of the system. Because of that, this approach is experimental and may interfere with normal touch handling or may not behave as expected on a particular Android build. It is not a guaranteed, production-safe implementation.

The service requests no window-content access, does not take screenshots, does not request internet access, and contains no analytics or ads. Android still displays a high-impact Accessibility permission warning. Enable it only if you understand and accept the trade-off. If touch input behaves strangely, immediately disable the service in Settings > Accessibility.

## Build with Android Studio

1. Install the latest stable Android Studio.
2. Extract `PixelDoubleTap-AndroidStudio-Project.zip`.
3. In Android Studio choose **Open** and select the extracted `PixelDoubleTap` folder (the one containing `settings.gradle.kts`).
4. Allow Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
5. Connect your Pixel 8a with USB debugging enabled, or use an emulator.
6. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show a notification with **Locate**. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
8. Transfer the APK to your phone and install it. You may need to allow your file manager to install unknown apps.
9. Open Pixel Double Tap, tap **Open Accessibility settings**, and enable the service if you decide to test it.
10. To stop it, go to **Settings > Accessibility > Pixel Double Tap** and switch it off, or uninstall the app.

## Requirements

- Android 14 (API 34) or newer for touchscreen motion-event listening.
- Android Studio with JDK 17 and Android SDK Platform 35.
- No Gradle wrapper is included; Android Studio can use its configured Gradle installation and download the required Gradle version during sync.

## Behaviour

- Double-tap window: 350 ms.
- Maximum distance between taps: 72 px.
- Locks using `GLOBAL_ACTION_LOCK_SCREEN`.
- The current launcher package is resolved dynamically.
