plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.asif.pixeldoubletap"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.asif.pixeldoubletap"
        minSdk = 34
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
