package com.asif.pixeldoubletap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.InputDevice
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager

class HomeTapService : AccessibilityService() {
    private var homePackage: String? = null
    private var currentPackage: String? = null
    private var lastTapTime = 0L
    private var lastX = 0f
    private var lastY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()

        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        homePackage = packageManager.resolveActivity(homeIntent, 0)
            ?.activityInfo?.packageName

        // API 34+: request touchscreen MotionEvents. No screen-content access is requested.
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            val info = serviceInfo
            info.setMotionEventSources(InputDevice.SOURCE_TOUCHSCREEN)
            serviceInfo = info
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        currentPackage = event?.packageName?.toString()
    }

    override fun onMotionEvent(event: MotionEvent) {
        if (currentPackage != homePackage || homePackage == null) return
        if (event.actionMasked != MotionEvent.ACTION_UP) return

        val now = event.eventTime
        val x = event.x
        val y = event.y
        val elapsed = now - lastTapTime
        val dx = x - lastX
        val dy = y - lastY
        val closeEnough = (dx * dx + dy * dy) < (72f * 72f)

        if (lastTapTime != 0L && elapsed in 40L..350L && closeEnough) {
            lastTapTime = 0L
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            lastTapTime = now
            lastX = x
            lastY = y
        }
    }

    override fun onInterrupt() {
        lastTapTime = 0L
    }
}
