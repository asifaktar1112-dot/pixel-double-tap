package com.asif.pixeldoubletap

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF101014.toInt())
        }

        val title = TextView(this).apply {
            text = "Pixel Double Tap"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Double-tap an empty area of your home screen to turn the display off."
            textSize = 16f
            setTextColor(0xFFB9B9C3.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val warning = TextView(this).apply {
            text = "Permission note\nThis experimental feature uses Android Accessibility to receive touchscreen motion events. Android may restrict this on some devices, and touch behaviour may be affected. The app does not request internet access and does not read screen content."
            textSize = 14f
            setTextColor(0xFFFFD6A5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val enable = Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val how = TextView(this).apply {
            text = "\nEnable “Pixel Double Tap” under Downloaded apps / Installed apps. Return here after enabling. To turn it off, disable the same service in Accessibility settings."
            textSize = 14f
            setTextColor(0xFFB9B9C3.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(warning)
        root.addView(enable)
        root.addView(how)
        setContentView(root)
    }
}
